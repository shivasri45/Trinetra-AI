# Model Card - Diagnostic Models

Regenerate the numbers with:

```
python -m backend.simulator.generate_dataset
python -m backend.ml.train
```

Live values are served at `GET /model/metrics` and written to `models/metrics.json`.

---

## Intended use

Detect and identify degradation and fault conditions in a **simulated** aero
piston engine, for research, demonstration and architecture evaluation.

**Not** for airworthiness, dispatch, maintenance release or any decision
affecting a real aircraft. The training data is synthetic and the model has never
seen a real engine.

---

## Models

| Model | Purpose | Training data | Key hyperparameters |
| --- | --- | --- | --- |
| `IsolationForest` | unsupervised novelty; covers failure modes that were never labelled | healthy samples only | 300 trees, contamination 0.02 |
| `RandomForestClassifier` | fault identification with class probabilities | all 10 classes | 400 trees, min_samples_leaf 2, balanced_subsample |
| `StandardScaler` | feature scaling | training split only | fitted before either model |

A third detector, the mean normalised innovation squared from the Kalman twin, is
model-based and requires no training. All three are fused in
`backend/ml/diagnostics.py`.

---

## Data

| Property | Value |
| --- | --- |
| Samples | 31,000 |
| Features | 93 |
| Classes | 10 (`normal` plus 9 fault modes) |
| Sessions | 130 independent runs |
| Mission profiles | normal cruise, high altitude, hot weather, long endurance, rapid throttle transition |
| Generator | `backend/simulator/generate_dataset.py` |

Each session warms the engine, lets the filters converge, then injects one fault
and records its whole development from incipient to fully expressed, so the
classifier sees early-stage faults and not only obvious ones. Six extra
envelope-randomised healthy sessions per profile densify the healthy manifold,
because the novelty detector's decision boundary is drawn entirely from it.

The rapid throttle transition profile is included deliberately so the classifier
learns that a healthy transient is not a fault.

---

## Evaluation protocol

Split by **session identifier** using `GroupShuffleSplit`, 25 % held out
(97 training sessions, 33 test sessions).

Consecutive samples within one run are strongly autocorrelated. A plain random
split would place nearly identical rows on both sides of the boundary and report
an accuracy that does not survive contact with new data. No session contributes
to both sides.

---

## Results on held-out sessions

| Metric | All test rows | Expressed faults only |
| --- | --- | --- |
| Accuracy | 0.981 | 0.9994 |
| Macro F1 | 0.977 | 0.9982 |
| Samples | 7,750 | 7,128 |

Both figures are reported because they answer different questions, and the gap
between them is itself the result.

The dataset labels a row with its fault from the tick of injection, but the
physics needs time to express: sensor drift ramps over 120 s and a cylinder head
has a time constant near 20 s. Rows inside that window carry a label the
instruments cannot yet support, so scoring them measures the labelling
convention rather than the model. The **expressed** column restricts scoring to
healthy rows plus fault rows past severity 0.6, the same threshold already used
for the novelty measurement below.

Read together: once a fault is physically observable the classifier identifies it
almost perfectly, and essentially all of the residual 1.9 % error in the headline
figure lives in the incipient window. The confusion matrix in `metrics.json`
confirms the mechanism - nearly every misclassification is a fault row predicted
`normal`, and the rate per class tracks that class's ramp time, from `misfire`
(6 s ramp, zero errors) to `sensor_drift` (120 s ramp, worst).

This is not a licence to quote only the flattering number. The incipient window
is real, and detection latency is the honest measure of it - see the
per-fault latency table below.

Per-class F1 over all test rows:

| Class | F1 |
| --- | --- |
| misfire | 1.000 |
| excessive_vibration | 0.999 |
| alternator_failure | 0.998 |
| combustion_instability | 0.997 |
| injector_abnormality | 0.996 |
| lubrication_issue | 0.981 |
| normal | 0.979 |
| coking_degradation | 0.969 |
| overheating | 0.943 |
| sensor_drift | 0.909 |

Novelty detector threshold trade-off, measured on held-out healthy data, with
detection scored only where fault severity exceeds 0.6:

| Healthy quantile | False alarm rate | Developed-fault detection |
| --- | --- | --- |
| p95 | 0.050 | 0.676 |
| p98 | 0.020 | 0.580 |
| **p99 (operating point)** | **0.010** | **0.491** |
| p99.5 | 0.005 | 0.414 |
| p99.9 | 0.001 | 0.270 |

The conservative operating point is a deliberate choice: novelty exists to catch
unlabelled behaviour, while sensitivity is carried by the statistical and
supervised detectors. Read on its own the detection column looks weak; in the
fused system it is a safety net, not the primary detector.

### End-to-end behaviour

Measured through the full pipeline with alarm debouncing, which is what actually
matters. These numbers are not from the static test matrix.

| Measurement | Result |
| --- | --- |
| False alarms, healthy engine, all five profiles | 0 of 1250 samples |
| Detection latency | 3 s (misfire, vibration, alternator) to 75 s (sensor drift) |
| Correct identification once developed | 100 % of samples, all nine faults |
| Limiting subsystem correctly attributed | 9 of 9 faults |

Per-fault detection latency at cruise:

| Fault | Detected | Fault | Detected |
| --- | --- | --- | --- |
| misfire | 3 s | coking_degradation | 25 s |
| excessive_vibration | 4 s | overheating | 36 s |
| alternator_failure | 4 s | sensor_drift | 75 s |
| combustion_instability | 7 s | | |
| injector_abnormality | 11 s | | |
| lubrication_issue | 19 s | | |

---

## Most influential features

| Feature | Importance | Reading |
| --- | --- | --- |
| `alternator_output_isolation` | 0.037 | electrical bus analytical redundancy |
| `vib_order_0p5_ratio` | 0.036 | half crank order, single-cylinder misfire |
| `vib_order_1p5_ratio` | 0.035 | 1.5x sideband, combustion irregularity |
| `cht_drift` | 0.034 | learned slow bias on head temperature, the sensor-drift signature |
| `vib_imbalance_index` | 0.034 | first-order to firing-order ratio, rotating imbalance |
| `vib_order_1p0_ratio` | 0.034 | first order amplitude |
| `vibration_nres` | 0.034 | overall vibration innovation |
| `alternator_output_nres` | 0.032 | alternator current innovation |
| `vib_misfire_index` | 0.032 | half-order to firing-order ratio |
| `oil_pressure_cond_nres` | 0.029 | pressure against the temperature-conditioned expectation |
| `power_kw_rel` | 0.028 | shaft power relative to expectation |

The ranking is dominated by physically interpretable quantities rather than raw
readings, which is a consequence of feeding the models normalised innovations and
crank-order ratios instead of gauge values.

---

## Feature construction and leakage controls

Features are defined once in `backend/preprocessing/pipeline.py` and that same
code is driven by both the dataset generator and the live service, so train/serve
skew has no way in.

Structural guarantees, each covered by a test in `tests/test_diagnostics.py`:

- `Diagnostics.analyse(features, twin)` has no parameter that could carry the
  injected fault, severity or simulator wear state.
- `FeatureBuilder.transform(telemetry, twin, vibration, cylinders)` likewise.
- No feature name contains `fault`, `label`, `truth`, `severity`, `wear`,
  `injected` or `mission`.
- The telemetry frame itself carries no fault information. Ground truth travels in
  a separate `simulated_truth` field on the snapshot, for demonstration and
  offline scoring only.

Features are dimensionless wherever possible - normalised innovations, crank
orders referenced to the firing order, ratios against expectation - so a model
trained at one operating point stays valid across the envelope.

---

## Validation against a published specification

The engine parameters correspond to a **Rotax 912 ULS/S**. Four are the
manufacturer's published figures and can be checked independently; the rest are
modelling assumptions. Distinguishing the two is the point of this section.

| Parameter | Source | Value |
| --- | --- | --- |
| Displacement | published | 1352 cm3 |
| Rated output | published | 73.5 kW / 100 hp |
| Speed at rated output | published | 5800 rpm (take-off, 5 min limit) |
| Max CHT | published | 135 C |
| Compression ratio | **uncertain** | 10.5:1 used; sources also give 11:1 |
| Idle speed, TBO, fuel properties | assumed | plausible for the class, not sourced |
| The seven constants in `physics.py` | **fitted** | tuned to land near the rating |

Manufacturer specification: <https://www.flyrotax.com/products/912-uls-s>.
Operating limits appear in the 912 series Operator's Manual; the CHT figure is
also quoted in NTSB docket excerpts of the manufacturer's manuals. Engines
converted to coolant-temperature measurement use a 120 C limit instead.

### Model output at reference conditions

ISA sea level, 15 C, 101.325 kPa.

| Condition | Quantity | Model | Published | Delta |
| --- | --- | --- | --- | --- |
| Full throttle | Power | 67.6 kW | 73.5 kW | **-8.1 %** |
| Full throttle | Speed | 5639 rpm | 5800 rpm | -2.8 % |
| Full throttle | BSFC | 0.262 kg/kWh | not sourced | - |
| 75 % throttle | Power | 52.6 kW (71.6 % rated) | - | - |
| 75 % throttle | Fuel flow | 17.6 L/h | not sourced | - |
| 75 % throttle | Oil temperature | 97.3 C | 90-110 C normal | in range |
| 75 % throttle | Oil pressure | 51.8 psi | within normal band | in range |
| 75 % throttle | CHT | 184.3 C | 135 C maximum | **+49 C over limit** |
| 75 % throttle | EGT | 728.6 C | below installation limits | plausible |

### Two discrepancies, stated plainly

**Power is 8 % low at full throttle.** `tests/test_physics.py` asserts rated
power within a 12 % tolerance, so this passes, but the tolerance is loose enough
that it was not previously visible. The model also reaches its peak at 5639 rpm
rather than 5800.

**CHT runs about 50 C above the published maximum.** This is the more serious
one. The real 912 has liquid-cooled heads; `head_temperature()` implements
forced-convection *air* cooling (`Nu ~ Re^0.8` on air mass flux), so the heat
rejection path is wrong for this engine and `COOLING_COEFF` was fitted to a
temperature band that is not the real one. A normal cruise point therefore sits
above the real engine's red line.

What this does and does not affect. Detection and identification are unaffected,
because every health index and residual is measured against the model's *own*
expectation rather than against an absolute limit - the twin and the simulated
engine share `EnginePhysics`, so a consistent offset cancels. What it does affect
is any claim that the absolute instrument readings correspond to a real 912, and
it means the thermal limits shown on the dashboard are not the aircraft's limits.

Fixing it means refitting `COOLING_COEFF` against a liquid-cooled head model,
which changes every temperature in the dataset and invalidates the trained
bundle and all metrics above. It is deliberately left as a recorded defect rather
than a silent retune.

Finding both of these took one afternoon of comparing model output against
published figures, which is an argument for doing this kind of check early.

---

## Rejected changes

Recorded because a measured negative result is worth as much as a positive one,
and because both of these look obviously correct on paper.

### Envelope jitter on fault sessions

The generator randomises throttle, ambient temperature, ambient pressure and
airspeed ratio for the extra healthy sessions, so the novelty detector sees a
continuous healthy manifold rather than five discrete operating points. Fault
sessions run at their profile's nominal conditions instead, which means every
fault is only ever observed at one operating point per profile - an obvious
asymmetry to want to close.

Applying the same jitter to fault sessions was measured and made things clearly
worse:

| Configuration | Accuracy | Macro F1 | `sensor_drift` F1 |
| --- | --- | --- | --- |
| Nominal fault sessions (shipped) | 0.981 | 0.977 | 0.909 |
| Jittered fault sessions | 0.950 | 0.878 | **0.000** |

`sensor_drift` stopped being predicted at all. The mechanism is that sensor drift
is a slow bias on cylinder head temperature, detected largely through the
`cht_drift` feature, and an ambient temperature spread of sigma 9 K is large
relative to the bias being detected. Widening the envelope hides the subtlest
fault signature underneath benign variation.

Two things worth taking from this. Fault-envelope coverage is still a real gap,
but it needs a spread chosen per fault rather than the healthy-session spread
reused wholesale. And more importantly, the fragility is not purely an artefact
of the dataset: if a 9 K ambient shift can mask sensor drift here, then ambient
variation in flight - which is far wider than 9 K - deserves investigation as a
robustness question about the estimator, not just the training data.

### Severity weighting of fault rows

Weighting each fault row by its severity when fitting the classifier, so early
rows contribute in proportion to how far the fault has actually developed. This
is principled - it encodes confidence in the label rather than asserting it - but
measured on the current dataset it moved expressed macro F1 by roughly 0.001,
which is inside single-split noise.

Retained as `train(weight_by_severity=...)`, defaulting to off. It is worth
revisiting with multiple dataset realisations, where an effect that small could
actually be resolved.

---

## Known limitations

- **Synthetic data.** Performance reflects the simulator's fault physics. A real
  engine will show correlations, sensor faults and failure modes not represented
  here, and these numbers should not be expected to transfer.
- **Sensor drift is the weakest class** (F1 0.909, 75 s latency). It is the
  hardest case by construction: the deviation is slow, small per sample, and
  partly absorbed by baseline adaptation before it becomes conspicuous. It is
  also the one fault the physics-rule fallback cannot name on its own.
- **Overheating F1 is 0.943**, the second weakest. Its early stage overlaps with
  a hot-weather cruise, which is exactly the ambiguity the mission profile
  context features exist to resolve, and they do not resolve it perfectly.
- **Single fault at a time.** The classifier is trained on one active fault per
  session and is not validated on simultaneous faults.
- **One engine configuration.** Trained for a single 1.35 L four-cylinder
  specification; another engine needs retraining.
- **No calibration guarantee on probabilities.** Confidence is a fused score, not
  a calibrated posterior. It should be read as a ranking, not as a probability of
  being correct.
- **Version pinning.** scikit-learn does not guarantee unpickling across minor
  releases, hence the pinned `requirements.txt`. The loader validates the feature
  schema and falls back to physics rules if it has changed.

---

## Graceful degradation

If the model bundle is missing, unreadable or built against a different feature
schema, `Diagnostics` reports `model_backend: physics_prior_fallback` and
continues on the transparent physics rules and the statistical residual tests
alone. It does not silently claim to be a trained model.

Measured fallback capability, same conditions as above:

| Outcome | Faults |
| --- | --- |
| Detected and correctly named | 8 of 9 (misfire, injector, overheating, lubrication, coking, combustion instability, excessive vibration, alternator) |
| Not detected | sensor drift |
| False alarm on a healthy engine | none |

So the deterministic path alone covers everything except the fault that depends
most on learned behaviour. That matters for the certification argument in
`docs/deployment_roadmap.md`: the safety-relevant detection capability does not
require the trained model.
